IMPORTANT

Content of this folder cannot be accessed without the internal secret token
created for each request to any of the "web accessible resources".

Any fetch operation made without uBlock Origin's internal secret will result
in failure. This means that despite the content of the folder here declared as
"web accessible resources", it still cannot be seen by the outside world.

Only uBlock Origin knows the secret token at runtime and hence only
uBlock Origin can access the content of this folder.
