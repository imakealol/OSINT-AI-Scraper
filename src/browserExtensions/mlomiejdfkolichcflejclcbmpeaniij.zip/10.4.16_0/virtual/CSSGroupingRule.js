var CSSGroupingRule = {};

export { CSSGroupingRule as __exports };
