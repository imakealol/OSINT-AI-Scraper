var CSSSupportsRule = {};

export { CSSSupportsRule as __exports };
