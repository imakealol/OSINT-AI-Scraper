var CSSKeyframesRule = {};

export { CSSKeyframesRule as __exports };
