var CSSStyleSheet = {};

export { CSSStyleSheet as __exports };
