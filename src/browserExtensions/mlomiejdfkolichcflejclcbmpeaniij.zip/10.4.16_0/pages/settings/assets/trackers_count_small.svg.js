const __vite_glob_0_6 = "/assets/trackers_count_small.svg";

export { __vite_glob_0_6 as default };
