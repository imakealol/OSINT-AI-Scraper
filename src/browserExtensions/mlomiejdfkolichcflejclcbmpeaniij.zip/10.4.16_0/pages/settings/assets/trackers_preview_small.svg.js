const __vite_glob_0_8 = "/assets/trackers_preview_small.svg";

export { __vite_glob_0_8 as default };
