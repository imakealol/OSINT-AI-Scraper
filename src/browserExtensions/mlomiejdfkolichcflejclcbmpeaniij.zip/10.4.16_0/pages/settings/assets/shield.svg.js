const __vite_glob_0_4 = "/assets/shield.svg";

export { __vite_glob_0_4 as default };
