const __vite_glob_0_2 = "/assets/hands.svg";

export { __vite_glob_0_2 as default };
