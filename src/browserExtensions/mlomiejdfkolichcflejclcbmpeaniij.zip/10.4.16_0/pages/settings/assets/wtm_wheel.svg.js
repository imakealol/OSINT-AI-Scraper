const __vite_glob_0_9 = "/assets/wtm_wheel.svg";

export { __vite_glob_0_9 as default };
