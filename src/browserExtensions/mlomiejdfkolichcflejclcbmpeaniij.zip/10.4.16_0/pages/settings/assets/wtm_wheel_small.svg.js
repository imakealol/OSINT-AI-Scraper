const __vite_glob_0_10 = "/assets/wtm_wheel_small.svg";

export { __vite_glob_0_10 as default };
