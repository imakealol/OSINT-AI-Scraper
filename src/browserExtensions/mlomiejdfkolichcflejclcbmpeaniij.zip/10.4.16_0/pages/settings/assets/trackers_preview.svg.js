const __vite_glob_0_7 = "/assets/trackers_preview.svg";

export { __vite_glob_0_7 as default };
