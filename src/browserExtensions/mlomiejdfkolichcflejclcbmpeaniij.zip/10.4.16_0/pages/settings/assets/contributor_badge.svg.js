const __vite_glob_0_1 = "/assets/contributor_badge.svg";

export { __vite_glob_0_1 as default };
