import __vite_glob_0_0 from './components/layout.js';
import define from '../../npm/hybrids/src/define.js';

define.from(
  /* #__PURE__ */ Object.assign({"./components/layout.js": __vite_glob_0_0


}),
  {
    root: ['components'],
    prefix: 'trackers-preview',
  },
);
