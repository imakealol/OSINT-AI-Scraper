const pinExtensionOpera = "/assets/pin-extension-opera.jpg";

export { pinExtensionOpera as default };
